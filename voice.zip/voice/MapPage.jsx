import { useLocation, useNavigate } from "react-router-dom";
import {
  MapContainer,
  TileLayer,
  Marker,
  Polyline,
  useMap,
} from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useState, useRef } from "react";
import axios from "axios";

// 🚗 Car Icon
const carIcon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/744/744465.png",
  iconSize: [32, 32],
  iconAnchor: [16, 16],
});

function FollowUser({ position }) {
  const map = useMap();

  useEffect(() => {
    if (position) {
      map.flyTo(position, 17, { duration: 0.5 });
    }
  }, [position, map]);

  return null;
}

export default function MapPage() {
  const location = useLocation();
  const navigate = useNavigate();

  const { routeData, start, end } = location.state || {};
  const [currentPos, setCurrentPos] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef(null);
  const watchRef = useRef(null);


  useEffect(() => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported");
      return;
    }

    watchRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        setCurrentPos([pos.coords.latitude, pos.coords.longitude]);
      },
      () => alert("Location permission denied"),
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
    );

    return () => navigator.geolocation.clearWatch(watchRef.current);
  }, []);


  const sendToBackend = async (audioBlob) => {
    if (!currentPos) {
      alert("Location not available");
      return;
    }

    try {
      const formData = new FormData();
      formData.append("lat", currentPos[0]);
      formData.append("lon", currentPos[1]);
      formData.append("audio", audioBlob, "audio.wav");

      const response = await axios.post(
        "http://127.0.0.1:5001/analyze",
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );

      if (response.data.status === "ALERT") {
        alert("🚨 Emergency Sent to: " + response.data.station);
      } else {
        alert("No emergency detected");
      }
    } catch (error) {
      console.error(error);
      alert("Server error");
    }
  };


  const startRecording = async () => {
    try {
      setIsRecording(true);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);

      let chunks = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      
      mediaRecorderRef.current.onstop = async () => {
        const blob = new Blob(chunks, { type: "audio/wav" });
        await sendToBackend(blob);
        setIsRecording(false);
        chunks = [];
      };

      mediaRecorderRef.current.start();

      
      setTimeout(() => {
        if (mediaRecorderRef.current?.state !== "inactive") {
          mediaRecorderRef.current.stop();
        }
      }, 10000);

    } catch (err) {
      console.error(err);
      alert("Microphone permission denied");
      setIsRecording(false);
    }
  };

 
  const handleEmergency = () => {
    if (!isRecording) startRecording();
  };

  if (!start || !end) {
    return (
      <div style={{ padding: "40px" }}>
        <h2>No route selected</h2>
        <button onClick={() => navigate("/planner")}>Back to Planner</button>
      </div>
    );
  }

  return (
    <>
    
      <div style={{ height: "90vh" }}>
        <MapContainer center={[start.lat, start.lng]} zoom={15} style={{ height: "100%", width: "100%" }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

          <Marker position={[start.lat, start.lng]} />
          <Marker position={[end.lat, end.lng]} />

          {routeData?.geometry && (
            <Polyline
              positions={routeData.geometry.coordinates.map((c) => [c[1], c[0]])}
              pathOptions={{ color: "blue", weight: 5 }}
            />
          )}

          {currentPos && (
            <>
              <Marker position={currentPos} icon={carIcon} />
              <FollowUser position={currentPos} />
            </>
          )}
        </MapContainer>
      </div>

    
      <div
        style={{
          position: "absolute",
          bottom: "20px",
          left: "50%",
          transform: "translateX(-50%)",
        }}
      >
        <button
          onClick={handleEmergency}
          disabled={isRecording}
          style={{
            backgroundColor: "red",
            color: "white",
            padding: "15px 30px",
            fontSize: "16px",
            borderRadius: "5px",
            cursor: isRecording ? "not-allowed" : "pointer",
          }}
        >
          {isRecording ? "Recording..." : "Emergency Alert"}
        </button>
      </div>
    </>
  );
}
