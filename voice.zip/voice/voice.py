from flask import Flask, request, jsonify
import pandas as pd
import whisper
import tempfile
import os
from twilio.rest import Client
import time
from flask_cors import CORS






app = Flask(__name__)



EMERGENCY_WORDS = [
    "help", "emergency", "police",
    "bachao", "madad", "pulis",
    "बचाओ", "मदद", "पुलिस"
]
DURATION = 5
SAMPLE_RATE = 16000
COOLDOWN = 60  

TWILIO_SID = "ACe7b99837650bf7c1c524d9176a2a4edd"
TWILIO_TOKEN = "67906856f6e82d001c7e19ecc703af2e"
TWILIO_FROM = "+16184254539"
EMERGENCY_NUMBER = "+918824523532"  

POLICE_STATION_FILE = "police_stations.xlsx"



print("Loading Whisper model...")
model = whisper.load_model("base")
print("Model loaded!")


try:
    police_df = pd.read_excel(POLICE_STATION_FILE)

    # Clean header names (CRITICAL)
    police_df.columns = (
        police_df.columns
        .str.strip()
        .str.lower()
    )

    print("Detected columns:", police_df.columns.tolist())

    
    police_df["latitude"] = pd.to_numeric(police_df["latitude"], errors="coerce")
    police_df["longitude"] = pd.to_numeric(police_df["longitude"], errors="coerce")

    police_df["phone_number"] = (
    police_df["phone_number"]
    .astype(str)
    .str.replace(r"\D", "", regex=True)    
    .apply(lambda x: "+91" + x[-10:] if len(x) >= 10 else "")
)


    
    police_df = police_df.dropna(subset=["latitude", "longitude"])

    print(f"✅ Police station data loaded successfully with {len(police_df)} stations.")

except Exception as e:
    print(f"Error loading police station data: {e}")
    police_df = pd.DataFrame()





last_alert_time = 0

def haversine(lat1, lon1, lat2, lon2):
    """Compute distance (in km) between two coordinates"""
    from math import radians, sin, cos, asin, sqrt
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * asin(sqrt(a))
    return 6371 * c


def send_sms(text, emergency_number):
    client = Client(TWILIO_SID, TWILIO_TOKEN)
    client.messages.create(
        body=f"🚨 Emergency detected!\nSpeech: {text}",
        from_=TWILIO_FROM,
        to=emergency_number
    )
    print(" SMS Sent!")

def get_nearest_police_station(user_lat, user_lon):
    """Find the nearest police station based on the user's location"""
    global police_df
    if police_df.empty:
        return None

    police_df["Distance_km"] = police_df.apply(
        lambda r: haversine(user_lat, user_lon, float(r["latitude"]), float(r["longitude"])),
        axis=1
    )

    nearest_station = police_df.loc[police_df["Distance_km"].idxmin()]
    return nearest_station

def process_audio(file, user_lat, user_lon):
    global last_alert_time

    result = model.transcribe(file)
    detected_language = result["language"]
    text = result["text"].lower()

    print("Language:", detected_language)
    print(" Speech:", text)

    if detected_language not in ["en", "hi"]:
        print(" Only Hindi & English supported.")
        return

    if any(word in text for word in EMERGENCY_WORDS):
        current_time = time.time()

        if current_time - last_alert_time > COOLDOWN:
            print(" EMERGENCY DETECTED!")

            # Find nearest police station
            nearest_station = get_nearest_police_station(user_lat, user_lon)
            if nearest_station is not None:
                print(f"📍 Nearest Police Station: {nearest_station['station_name']} - {nearest_station['phone_number']}")
                send_sms(text, nearest_station["phone_number"])
                last_alert_time = current_time
            else:
                print("❌ No valid police station found.")
        else:
            print("⏳ Cooldown active.")
    else:
        print("✅ No emergency word detected.")


    

@app.route("/analyze", methods=["POST"])
def analyze():
    try:
      
        lat = float(request.form["lat"])
        lon = float(request.form["lon"])
        audio_file = request.files["audio"]

     
        if not audio_file:
            return jsonify({"error": "Audio file is required"}), 400

       
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
            audio_file.save(tmp.name)
            filepath = tmp.name

      
        result = model.transcribe(filepath)
        text = result["text"].lower()

    
        os.remove(filepath)

        print("Detected speech:", text)

       
        if any(word in text for word in EMERGENCY_WORDS):
            station = get_nearest_police_station(lat, lon)

            if station is not None:
                send_sms(text, station["phone_number"])

            return jsonify({
                "status": "ALERT",
                "speech": text,
                "station": station["station_name"]
            })

        return jsonify({
            "status": "OK",
            "speech": text
        })

    except Exception as e:
        print(f"Error during processing: {e}")
        return jsonify({"error": "Bad request"}), 400


CORS(app)

if __name__ == "__main__":
    app.run(port=5001)

